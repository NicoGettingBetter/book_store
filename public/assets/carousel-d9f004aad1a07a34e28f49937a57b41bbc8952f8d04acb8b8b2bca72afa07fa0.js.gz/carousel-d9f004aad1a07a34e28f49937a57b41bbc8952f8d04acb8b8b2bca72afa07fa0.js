$(document).ready( function() {
    $(".owl-carousel").owlCarousel({
      autoPlay: 5000,
      singleItem:true
    });
  } );
